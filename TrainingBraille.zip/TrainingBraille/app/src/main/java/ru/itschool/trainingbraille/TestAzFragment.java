package ru.itschool.trainingbraille;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

public class TestAzFragment extends Fragment implements View.OnClickListener {
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.testaz_fragment, container, false);
        Button button_a = (Button) view.findViewById(R.id.braille_a);
        Button button_ge = (Button) view.findViewById(R.id.braille_ge);
        Button button_p = (Button) view.findViewById(R.id.braille_p);
        Button button_f = (Button) view.findViewById(R.id.braille_f);
        Button button_k = (Button) view.findViewById(R.id.braille_k);
        Button button_ie = (Button) view.findViewById(R.id.braille_ie);
        Button button_y = (Button) view.findViewById(R.id.braille_y);
        Button button_h = (Button) view.findViewById(R.id.braille_h);
        Button button_s = (Button) view.findViewById(R.id.braille_s);
        Button button_tvz = (Button) view.findViewById(R.id.braille_tvz);
        Button button_ce = (Button) view.findViewById(R.id.braille_ce);
        Button button_ge2 = (Button) view.findViewById(R.id.braille_ge2);
        Button button_nextles = (Button) view.findViewById(R.id.btn_nles);
        button_nextles.setOnClickListener(this);
        button_ge2.setOnClickListener(this);
        button_nextles.setOnClickListener(this);
        button_tvz.setOnClickListener(this);
        button_s.setOnClickListener(this);
        button_ce.setOnClickListener(this);
        button_a.setOnClickListener(this);
        button_ge.setOnClickListener(this);
        button_p.setOnClickListener(this);
        button_ie.setOnClickListener(this);
        button_f.setOnClickListener(this);
        button_h.setOnClickListener(this);
        button_k.setOnClickListener(this);
        button_y.setOnClickListener(this);
        return view;
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.braille_s) {
            Toast.makeText(getContext(), "Правильно. Приступай к следующей теме", Toast.LENGTH_LONG).show();
        } else if (v.getId() == R.id.braille_a || v.getId() == R.id.braille_k) {
            Toast.makeText(getContext(), "Правильно. Приступай к следующему заданию", Toast.LENGTH_LONG).show();
        } else if(v.getId()!=R.id.btn_nles) {
            Toast.makeText(getContext(), "Неправильно", Toast.LENGTH_LONG).show();
        }
        if (v.getId() == R.id.btn_nles) {
            Intent intent_lessons2 = new Intent(getActivity(), LessonsActivity.class);
            startActivity(intent_lessons2);
        }
    }
}
