package ru.itschool.trainingbraille;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

public class ChZnActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chzn);
        Bundle bundle=getIntent().getExtras();
        Window stroka = getWindow();
        stroka.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Button button_ntheme=(Button) findViewById(R.id.button9);
        Button button_main=(Button) findViewById(R.id.button10);
        button_ntheme.setOnClickListener(this);
        button_main.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.button9:{
                Intent intent_practic=new Intent(getApplicationContext(),PracticActivity.class);
                startActivity(intent_practic);
                break;
            }
            case R.id.button10:{
                Intent intent_main=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent_main);
                break;
            }
        }
    }
}
