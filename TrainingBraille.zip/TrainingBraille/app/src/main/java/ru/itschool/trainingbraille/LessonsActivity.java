package ru.itschool.trainingbraille;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

public class LessonsActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lessons);
        Window stroka = getWindow();
        stroka.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Bundle bundle=getIntent().getExtras();
        Button button_az=(Button) findViewById(R.id.button_az);
        Button button_sl=(Button) findViewById(R.id.btn_cifznak);
        button_az.setOnClickListener(this);
        button_sl.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.button_az:{
                Intent intent_aztest=new Intent(this,AztestActivity.class);
                startActivity(intent_aztest);
                break;
            }
            case R.id.btn_cifznak:{
                Intent intent_ch_zntest=new Intent(this,TChZNActivity.class);
                startActivity(intent_ch_zntest);
                break;
            }

        }
    }
}
