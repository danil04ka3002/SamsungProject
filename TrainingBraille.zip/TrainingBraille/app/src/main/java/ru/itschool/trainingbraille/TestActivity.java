package ru.itschool.trainingbraille;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.net.Inet4Address;

public class TestActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
        Bundle bundle=getIntent().getExtras();
        Window stroka = getWindow();
        stroka.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Button button_r=(Button) findViewById(R.id.button_testr);
        Button button_gmenu=(Button) findViewById(R.id.button_gmenu);
        button_r.setOnClickListener(this);
        button_gmenu.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button_testr: {
                EditText editText7 = (EditText) findViewById(R.id.editText7);
                EditText editText8 = (EditText) findViewById(R.id.editText8);
                EditText editText9 = (EditText) findViewById(R.id.editText9);
                final String otvet7 = editText7.getText().toString();
                final String otvet8 = editText8.getText().toString();
                final String otvet9 = editText9.getText().toString();
                int s, a, b, c;
                if (otvet7.equals("делу-время, потехе час.") || otvet7.equals("Делу-время, потехе час.")) {
                    a = 1;
                } else {
                    a = 0;
                }
                if (otvet8.equals("наш телефон 283-58-35.") || otvet8.equals("Наш телефон 283-58-35.")) {
                    b = 3;
                } else {
                    b = 0;
                }
                if (otvet9.equals("дети катаются на самокате.") || otvet9.equals("Дети катаются на самокате.")) {
                    c = 2;
                } else {
                    c = 0;
                }
                s = a + b + c;
                if (s == 6) {
                    Toast.makeText(getApplicationContext(), "Молодец! 6 баллов", Toast.LENGTH_LONG).show();
                } else if (s == 5) {
                    Toast.makeText(getApplicationContext(), "Молодец! 5", Toast.LENGTH_LONG).show();
                } else if (s == 4) {
                    Toast.makeText(getApplicationContext(), "Молодец! 4 балла", Toast.LENGTH_LONG).show();
                } else if (s == 3) {
                    Toast.makeText(getApplicationContext(), "3 балла", Toast.LENGTH_LONG).show();
                } else if (s == 2) {
                    Toast.makeText(getApplicationContext(), "2 балла", Toast.LENGTH_LONG).show();
                } else if (s == 1) {
                    Toast.makeText(getApplicationContext(), " 1 балл", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Увы, 0 баллов", Toast.LENGTH_LONG).show();
                }
                break;
            }
            case R.id.button_gmenu:{
                Intent intent_gmenu=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent_gmenu);
                break;
            }
        }
    }
}

