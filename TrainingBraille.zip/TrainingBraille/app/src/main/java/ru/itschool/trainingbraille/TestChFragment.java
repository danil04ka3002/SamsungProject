package ru.itschool.trainingbraille;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.fragment.app.Fragment;



public class TestChFragment extends Fragment implements View.OnClickListener {
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.testch_fragment, container, false);
        Button btn_ten = (Button) view.findViewById(R.id.braille_ten);
        Button btn_eight = (Button) view.findViewById(R.id.braille_eight);
        Button btn_seven = (Button) view.findViewById(R.id.braille_seven);
        Button btn_six = (Button) view.findViewById(R.id.braille_six);
        Button btn_quest = (Button) view.findViewById(R.id.braille_quest);
        Button btn_threet = (Button) view.findViewById(R.id.braille_threet);
        Button btn_zero = (Button) view.findViewById(R.id.braille_zero);
        Button btn_one = (Button) view.findViewById(R.id.braille_one);
        Button btn_voskl = (Button) view.findViewById(R.id.braille_voskl);
        Button btn_voskl2 = (Button) view.findViewById(R.id.braille_voskl2);
        Button btn_tz = (Button) view.findViewById(R.id.braille_tz);
        Button btn_defis = (Button) view.findViewById(R.id.braille_defis);
        Button next_activity=(Button) view.findViewById(R.id.btn_nles2);
        next_activity.setOnClickListener(this);
        btn_defis.setOnClickListener(this);
        btn_one.setOnClickListener(this);
        btn_eight.setOnClickListener(this);
        btn_six.setOnClickListener(this);
        btn_seven.setOnClickListener(this);
        btn_threet.setOnClickListener(this);
        btn_tz.setOnClickListener(this);
        btn_voskl.setOnClickListener(this);
        btn_voskl2.setOnClickListener(this);
        btn_zero.setOnClickListener(this);
        btn_quest.setOnClickListener(this);
        btn_ten.setOnClickListener(this);
        return view;
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.braille_ten) {
            Toast.makeText(getContext(), "Правильно. Приступай к следующей теме", Toast.LENGTH_LONG).show();
        } else if (v.getId() == R.id.braille_defis || v.getId() == R.id.braille_quest) {
            Toast.makeText(getContext(), "Правильно. Приступай к следующему заданию", Toast.LENGTH_LONG).show();

        } else if(v.getId()!=R.id.btn_nles2){
            Toast.makeText(getContext(), "Неправильно", Toast.LENGTH_LONG).show();
        }
        if (v.getId() == R.id.btn_nles2) {
            Intent intent_lessons = new Intent(getActivity(), LessonsTwoActivity.class);
            startActivity(intent_lessons);
        }
    }
}