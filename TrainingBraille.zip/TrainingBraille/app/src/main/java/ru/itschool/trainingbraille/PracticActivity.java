package ru.itschool.trainingbraille;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

public class PracticActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practic);
        Window stroka = getWindow();
        stroka.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Bundle bundle = getIntent().getExtras();
        Button btnmod_1=(Button) findViewById(R.id.button);
        Button btnmod_2=(Button) findViewById(R.id.button2);
        Button btn_test=(Button) findViewById(R.id.button3);
        btnmod_1.setOnClickListener(this);
        btnmod_2.setOnClickListener(this);
        btn_test.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.button:{
                Intent intent_mod1=new Intent(this,LessonsActivity.class);
                startActivity(intent_mod1);
                break;
            }
            case R.id.button2:{
                Intent intent_mod2=new Intent(this,LessonsTwoActivity.class);
                startActivity(intent_mod2);
                break;
            }
            case R.id.button3:{
                Intent intent_test=new Intent(this,TestActivity.class);
                startActivity(intent_test);
                break;
            }
        }
    }
}
