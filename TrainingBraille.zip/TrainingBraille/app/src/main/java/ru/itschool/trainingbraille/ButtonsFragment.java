package ru.itschool.trainingbraille;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import java.util.Objects;

public class ButtonsFragment extends Fragment implements View.OnClickListener {


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.buttons_fragment, container, false);
        Button button_traning = (Button) view.findViewById(R.id.button5);
        Button button_practic = (Button) view.findViewById(R.id.button4);
        Button button_exit=(Button) view.findViewById(R.id.button_exit);
        button_exit.setOnClickListener(this);
        button_traning.setOnClickListener(this);
        button_practic.setOnClickListener(this);
        return view;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button5: {
                Intent intent_traning = new Intent(getActivity(), TraningActivity.class);
                startActivity(intent_traning);
                break;
            }
            case R.id.button4: {
                Intent intent_practic = new Intent(getActivity(), PracticActivity.class);
                startActivity(intent_practic);
                break;

            }
            case R.id.button_exit:{
                getActivity().finish();



            }
        }
    }
}

