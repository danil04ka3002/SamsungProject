package ru.itschool.trainingbraille;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

public class LessonsTwoActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lessons2);
        Bundle bundle=getIntent().getExtras();
        Window stroka = getWindow();
        stroka.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Button button_sl=(Button) findViewById(R.id.button_slova);
        Button button_slch=(Button) findViewById(R.id.button_slchet);
        button_sl.setOnClickListener(this);
        button_slch.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.button_slova:{
                Intent intent_sl=new Intent(this,SlActivity.class);
                startActivity(intent_sl);
                break;
            }
            case R.id.button_slchet:{
                Intent intent_slch=new Intent(this, SlChActivity.class);
                startActivity(intent_slch);
                break;
            }
        }
    }
}
