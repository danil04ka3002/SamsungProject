package ru.itschool.trainingbraille;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SlActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sl);
        Bundle bundle = getIntent().getExtras();
        Window stroka = getWindow();
        stroka.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Button btn_eq1 = (Button) findViewById(R.id.button17);
        Button btn_eq2=(Button) findViewById(R.id.button16);
        Button btn_eq3=(Button) findViewById(R.id.button18);
        Button btn_main=(Button) findViewById(R.id.button19);
        btn_eq1.setOnClickListener(this);
        btn_eq2.setOnClickListener(this);
        btn_eq3.setOnClickListener(this);
        btn_main.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.button17:{
                EditText editText1 = (EditText) findViewById(R.id.editText1);
                final String otvet1 = editText1.getText().toString();
                if (otvet1.equals("Брайль")||otvet1.equals("брайль")) {
                    Toast.makeText(getApplicationContext(), "Правильно", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Неправильно", Toast.LENGTH_LONG).show();
                }
                break;
            }
            case R.id.button16:{
                EditText editText2 = (EditText) findViewById(R.id.editText2);
                final String otvet2 = editText2.getText().toString();
                if(otvet2.equals("Шрифт")||otvet2.equals("шрифт")){
                    Toast.makeText(getApplicationContext(),"Правильно",Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(getApplicationContext(),"Неправильно",Toast.LENGTH_LONG).show();
                }
                break;

            }
            case R.id.button18:{
                EditText editText3=(EditText) findViewById(R.id.editText3);
                final String otvet3=editText3.getText().toString();
                if(otvet3.equals("Уроки")||otvet3.equals("уроки")){
                    Toast.makeText(getApplicationContext(),"Правильно",Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(getApplicationContext(),"Неправильно",Toast.LENGTH_LONG).show();

                }
                break;

            }
            case R.id.button19:{
                Intent intent_exit=new Intent(getApplicationContext(),LessonsTwoActivity.class);
                startActivity(intent_exit);
                break;
            }

        }
    }
}






