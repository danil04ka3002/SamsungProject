package ru.itschool.trainingbraille;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

public class TraningActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_traning);
        Window stroka = getWindow();
        stroka.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Bundle bundle = getIntent().getExtras();
        Button button_alf=(Button) findViewById(R.id.button6);
        Button button_znch=(Button) findViewById(R.id.button7);
        button_alf.setOnClickListener(this);
        button_znch.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.button6:{
                Intent intent_alf=new Intent(this,AzActivity.class);
                startActivity(intent_alf);
                break;
            }
            case R.id.button7:{
                Intent intent_chzn=new Intent(this,ChZnActivity.class);
                startActivity(intent_chzn);
                break;
            }
        }
    }
}
