package ru.itschool.trainingbraille;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SlChActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slch);
        Bundle bundle=getIntent().getExtras();
        Window stroka = getWindow();
        stroka.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Button btn_eq1 = (Button) findViewById(R.id.button16);
        Button btn_eq2=(Button) findViewById(R.id.button17);
        Button btn_eq3=(Button) findViewById(R.id.button18);
        Button btn_main=(Button) findViewById(R.id.button19);
        btn_eq1.setOnClickListener(this);
        btn_eq2.setOnClickListener(this);
        btn_eq3.setOnClickListener(this);
        btn_main.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.button16:{
                EditText editText4 = (EditText) findViewById(R.id.editText4);
                final String otvet4 = editText4.getText().toString();
                if (otvet4.equals("зашёл спросить")||otvet4.equals("Зашёл спросить")){
                    Toast.makeText(getApplicationContext(), "Правильно", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Неправильно", Toast.LENGTH_LONG).show();
                }
                break;

            }
            case R.id.button17:{
                EditText editText5 = (EditText) findViewById(R.id.editText5);
                final String otvet5 = editText5.getText().toString();
                if (otvet5.equals("плавающий лебедь")||otvet5.equals("Плавающий лебедь")) {
                    Toast.makeText(getApplicationContext(), "Правильно", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Неправильно", Toast.LENGTH_LONG).show();
                }
                break;

            }
            case R.id.button18:{
                EditText editText6 = (EditText) findViewById(R.id.editText6);
                final String otvet6 = editText6.getText().toString();
                if (otvet6.equals("каникулы в деревне")||otvet6.equals("Каникулы в деревне")) {
                    Toast.makeText(getApplicationContext(), "Правильно", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Неправильно", Toast.LENGTH_LONG).show();
                }
                break;

            }
            case R.id.button19:{
                Intent intent_prac=new Intent(getApplicationContext(),PracticActivity.class);
                startActivity(intent_prac);
                break;

            }
        }
    }
}
