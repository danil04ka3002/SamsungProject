package ru.itschool.trainingbraille;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

public class AzActivity extends AppCompatActivity implements View.OnClickListener {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_az);
        Bundle bundle = getIntent().getExtras();
        Window stroka = getWindow();
        stroka.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Button btnext_test = (Button) findViewById(R.id.button8);
        Button btn_main=(Button) findViewById(R.id.button11);
        btnext_test.setOnClickListener(this);
        btn_main.setOnClickListener(this);

    }
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.button8:{
                finish();
                Intent intent_chzn=new Intent(this,ChZnActivity.class);
                startActivity(intent_chzn);
                break;
            }
            case R.id.button11:{
                finish();
                Intent intent_main=new Intent(this,MainActivity.class);
                startActivity(intent_main);
                break;
            }
        }
    }
}
